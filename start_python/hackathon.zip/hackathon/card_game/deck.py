class Deck:
    '''
    Class đại diện cho bộ bài, bao gồm 36 lá
    '''

    def build(self):
        '''Tạo bộ bài'''
        pass

    def shuffle_card(self):
        '''Trộn bài'''
        pass

    def deal_card(self):
        '''Rút một lá bài từ bộ bài'''
